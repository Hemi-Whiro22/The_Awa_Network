"""Expose frontend assets to Python tooling when installed as a package."""
