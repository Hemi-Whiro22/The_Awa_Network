function ChatPanel() {
  return (
    <section>
      <h2>Chat</h2>
      <p>Conversation flow appears here.</p>
    </section>
  );
}

export default ChatPanel;
